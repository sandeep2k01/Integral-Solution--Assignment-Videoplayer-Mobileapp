"""
Routes package initialization.
"""
